#include <Wire.h>
#include <WiFi.h>
#include "time.h"
#include <LiquidCrystal_I2C.h>
#include <ESP32Servo.h>

// ================= WIFI =================
const char* ssid = ""; // <-- cambia aquí el nombre del WIFI
const char* password = ""; // <-- cambia aquí la contraseña del WIFI

// ================= NTP =================
const char* ntpServer = "pool.ntp.org";
const long gmtOffset_sec = -5 * 3600;
const int daylightOffset_sec = 0;

// ================= LCD =================
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ================= SERVO =================
Servo dispenserServo;
int servoPin = 18;

// ================= SENSORES =================
int irPin    = 23;
int ledVerde = 26;
int ledRojo  = 27;

// ================= CONTROL =================
bool medicacionEjecutada = false;
int targetHour   = ;   // <-- cambia aquí la hora
int targetMinute = ;  // <-- cambia aquí los minutos

// ========================================
// CONECTAR WIFI Y SINCRONIZAR HORA
// Se ejecuta UNA SOLA VEZ en setup()
// LCD muestra "Conectando WiFi..." mientras espera
// ========================================
void setupTime() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Conectando WiFi");

  WiFi.begin(ssid, password);
  int intentos = 0;
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    intentos++;
    if (intentos > 30) {
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("ERROR WiFi");
      lcd.setCursor(0, 1);
      lcd.print("Reinicia ESP32");
      while (true) delay(1000);
    }
  }

  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);

  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) {
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("ERROR NTP");
    return;
  }

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("WiFi OK!");
  delay(1000);
}

// ========================================
// FORMATO HORA AM/PM para el LCD
// Llamado cada segundo en loop()
// ========================================
String getTimeString(struct tm t) {
  int hour = t.tm_hour;
  int minute = t.tm_min;
  int second = t.tm_sec;

  String ampm = (hour >= 12) ? "PM" : "AM";
  int dh = hour;
  if (hour > 12) dh = hour - 12;
  if (dh == 0)   dh = 12;

  String hh = (dh < 10)     ? "0" + String(dh)     : String(dh);
  String mm = (minute < 10) ? "0" + String(minute)  : String(minute);
  String ss = (second < 10) ? "0" + String(second)  : String(second);

  return hh + ":" + mm + ":" + ss + " " + ampm;
}

// ========================================
// VERIFICAR SI EL IR DETECTA PASTILLA
// Lee el pin 10 veces seguidas
// Necesita 6 de 10 en LOW para confirmar
// LOW = hay objeto delante del sensor
// ========================================
bool verificarDispensado() {
  int countLow = 0;
  for (int i = 0; i < 10; i++) {
    if (digitalRead(irPin) == LOW) countLow++;
    delay(50);
  }
  return (countLow >= 6);
}

// ========================================
// SECUENCIA COMPLETA DE DISPENSACIÓN
// Se activa cuando llega targetHour:targetMinute
// 
// FLUJO:
// Intento 1 → servo gira → espera → IR verifica
//   → si detecta: MEDICAMENTO DISPENSADO (15 seg) → fin
//   → si no: muestra NO DETECTADO → espera 2 seg
// Intento 2 → igual
// Intento 3 → igual
//   → si falla los 3: ERROR SISTEMA (30 seg)
// ========================================
void dispensarMedicamento() {

  for (int i = 1; i <= 3; i++) {

    // --- Mostrar intento en LCD ---
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Dispensando...");
    lcd.setCursor(0, 1);
    lcd.print("Intento ");
    lcd.print(i);
    lcd.print("/3");

    Serial.print("Intento "); Serial.println(i);

    // --- Mover servo: 0 → 90° → vuelve a 0 ---
    dispenserServo.write(90);
    delay(1200);
    dispenserServo.write(0);
    delay(1500); // espera que caiga la pastilla

    // --- Verificar con IR ---
    bool detectado = verificarDispensado();
    Serial.print("IR: "); Serial.println(detectado ? "DETECTADO" : "NO detectado");

    if (detectado) {
      // ÉXITO
      digitalWrite(ledVerde, HIGH);
      digitalWrite(ledRojo, LOW);

      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("MEDICAMENTO");
      lcd.setCursor(0, 1);
      lcd.print("DISPENSADO OK");

      delay(15000); // muestra mensaje 15 segundos
      digitalWrite(ledVerde, LOW);
      return; // sale de la función
    }

    // No detectó → mostrar error parcial y reintentar
    digitalWrite(ledRojo, HIGH);
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("NO DETECTADO");
    lcd.setCursor(0, 1);
    lcd.print("REINTENTANDO...");
    delay(2000);
    digitalWrite(ledRojo, LOW);
  }

  // 3 intentos fallidos
  digitalWrite(ledRojo, HIGH);
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("ERROR SISTEMA");
  lcd.setCursor(0, 1);
  lcd.print("SIN PASTILLA");

  delay(30000);
  digitalWrite(ledRojo, LOW);
}

// ========================================
// SETUP — corre UNA VEZ al encender
// Orden: LCD → pines → servo → WiFi/NTP
// ========================================
void setup() {
  Serial.begin(115200);

  Wire.begin();
  lcd.init();
  lcd.backlight();

  pinMode(irPin,    INPUT_PULLUP);
  pinMode(ledVerde, OUTPUT);
  pinMode(ledRojo,  OUTPUT);
  digitalWrite(ledVerde, LOW);
  digitalWrite(ledRojo,  LOW);

  dispenserServo.attach(servoPin, 500, 2400);
  dispenserServo.write(0);

  lcd.setCursor(0, 0);
  lcd.print("SMARTMED AI");
  lcd.setCursor(0, 1);
  lcd.print("v1.0");
  delay(2000);

  // LED rojo mientras conecta
  digitalWrite(ledRojo, HIGH);
  setupTime();
  digitalWrite(ledRojo, LOW);

  // LED verde breve = listo
  digitalWrite(ledVerde, HIGH);
  delay(500);
  digitalWrite(ledVerde, LOW);
}

// ========================================
// LOOP — corre infinitamente
// Cada 1 segundo:
//   1. Obtiene hora NTP
//   2. Muestra hora y fecha en LCD
//   3. Verifica si es hora de dispensar
//   4. Reset automático a medianoche
// ========================================
void loop() {
  struct tm timeinfo;

  if (!getLocalTime(&timeinfo)) return;

  // --- Mostrar hora en fila 0 ---
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(getTimeString(timeinfo));

  // --- Mostrar fecha en fila 1 ---
  String date = String(timeinfo.tm_mday) + "/" +
                String(timeinfo.tm_mon + 1) + "/" +
                String(timeinfo.tm_year + 1900);
  lcd.setCursor(0, 1);
  lcd.print(date);

  // --- Debug IR en Serial Monitor ---
  Serial.print("IR: "); Serial.println(digitalRead(irPin));

  // --- Verificar si es la hora programada ---
  if (!medicacionEjecutada &&
      timeinfo.tm_hour == targetHour &&
      timeinfo.tm_min  == targetMinute) {
    medicacionEjecutada = true;
    dispensarMedicamento();
  }

  // --- Reset diario a medianoche ---
  if (timeinfo.tm_hour == 0 && timeinfo.tm_min == 0) {
    medicacionEjecutada = false;
  }

  delay(1000);
}